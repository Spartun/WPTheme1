<article class='post post-aside'>
    <div class="well">
        <small>
            <?php the_author(); ?>@<?php the_date( );?>
            <?php the_content(  );?>
        </small>
    </div>
</article>