<footer class="main-footer">
      <div class="container">
            <div class="f-left">
                <p>&copy; 2022 - Advanced WP Theme</p>
            </div>
            <div class="f-right">
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="about.html">About</a></li>
                <li><a href="index.html">Service</a></li>
                <li><a href="index.html">Blog</a></li>
            </ul>
            </div>
      </div> 
    </footer>
    <?php wp_footer(  );?>
  </body>
</html>
